import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class ContactServiceTest {

	//create a contact and test values
	@Test
	void testContactServiceClass() {
		ContactService.addContact("Jane", "Doe", "0987654321", "123 Four St. Riverside, CA 92503");
		assertTrue(ContactService.contactList.get(0).getId().equals("1000000002"));
		assertTrue(ContactService.contactList.get(0).getFirstName().equals("Jane"));
		assertTrue(ContactService.contactList.get(0).getLastName().equals("Doe"));
		assertTrue(ContactService.contactList.get(0).getPhone().equals("0987654321"));
		assertTrue(ContactService.contactList.get(0).getAddress().equals("123 Four St. Riverside, CA 92503"));
	}
	// confirm deletion of a contact
	@Test
	void testContactServiceDelete() {
		ContactService.addContact("Jane", "Doe", "0987654321", "123 Four St. Riverside, CA 92503");
		int size = ContactService.contactList.size();
		ContactService.deleteContact("1000000003");
		assertTrue(ContactService.searchContact("1000000003") == 2);
	}
	// update first name test
	@Test
	void testContactServiceUpdateFirstName() {
		ContactService.addContact("Sirius", "Black", "5556667777", "12 Grimmauld Place");
		int size = ContactService.contactList.size();
		System.out.println(ContactService.contactList.get(size - 1).getId());
		System.out.println(ContactService.contactList.get(size - 1).getFirstName());
		ContactService.updateFirstName("1000000003", "Regulus");
		System.out.println(ContactService.contactList.get(size - 1).getFirstName());
		assertTrue(ContactService.contactList.get(size - 1).getFirstName().equals("Regulus"));
	}
	// update last name test
	@Test
	void testContactServiceUpdateLastName() {
		int size = ContactService.contactList.size();
		ContactService.updateLastName("1000000003", "Kreacher");
		assertTrue(ContactService.contactList.get(size - 1).getLastName().equals("Kreacher"));
	}
	// update phone test
	@Test
	void testContactServiceUpdatePhone() {
		int target = 0;
		target = ContactService.findIndex("1000000003");
		ContactService.updatePhoneNum("1000000003", "7776665555");
		assertTrue(ContactService.contactList.get(target).getPhone().equals("7776665555"));
	}
	// update address test
	@Test
	void testContactServiceUpdateAddress() {
		int target = 0;
		target = ContactService.findIndex("1000000003");
		ContactService.updateAddress("1000000003", "Number Four Privet Drive");
		assertTrue(ContactService.contactList.get(target).getAddress().equals("Number Four Privet Drive"));
	}
	
	// test to confirm unique ID
	@Test
	void testContactServiceUniqueId() {
		Contact newContact = new Contact("98765", "Kevin", "Arnold", "5551234567", "Wonder Years");
		ContactService.addContact(newContact);
		Contact duplicateId = new Contact("98765", "Kevin", "Arnold", "5551234567", "Blunder Years");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			ContactService.addContact(duplicateId);
		});
	}

}