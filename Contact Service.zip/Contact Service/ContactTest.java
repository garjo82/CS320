import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class ContactTest {
	
	// test for contact creation
	@Test
	void testContactCalss() {
		Contact newContact = new Contact("1111", "Jane", "Doe", "0987654321", 
				"123 Four St. Riverside, CA 92503");
		assertTrue(newContact.getFirstName().equals("Jane"));
		assertTrue(newContact.getLastName().equals("Doe"));
		assertTrue(newContact.getId().equals("1111"));
		assertTrue(newContact.getPhone().equals("0987654321"));
		assertTrue(newContact.getAddress().equals("123 Four St. Riverside, CA 92503"));
	}
	// test ID length
	@Test
	void testContactClassIdTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678900", "Jane", "Doe", "0987654321", 
				"123 Four St. Riverside, CA 92503");
		});
	}
	// test ID length
	@Test
	void testContactClassIdNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(null, "Jane", "Doe", "0987654321", 
					"123 Four St. Riverside, CA 92503");
		});
	}
	// test first name length
	@Test
	void testContactClassFirstNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345", "Jane123456789", "Doe", "0987654321", 
					"123 Four St. Riverside, CA 92503");
		});
	}
	// test null first name
	@Test
	void testContactClassFirstNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345", null, "Doe", "0987654321",
					"123 Four St. Riverside, CA 92503");
		});
	}
	// test last name length
	@Test
	void testContactClassLastNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345", "Jane", "Doe123456789", "0987654321", 
					"123 Four St. Riverside, CA 92503");
		});
	}
	// test null last name
	@Test
	void testContactClassLastNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345", "Jane", null, "0987654321", 
					"123 Four St. Riverside, CA 92503");
		});
	}
	// test for not 10 characters
	@Test
	void testContactClassPhoneNot10() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345", "Jane", "Doe", "987654321", 
					"123 Four St. Riverside, CA 92503");
		});
	}
	// test null phone
	@Test
	void testContactCalssPhoneNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345", "Jane", "Doe", null, 
					"123 Four St. Riverside, CA 92503");
		});
	}
	// test address length
	@Test
	void testContactClassAddressTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345", "Jane", "Doe", "0987654321", 
					"123 Four St. Riverside, CA 92503 1234567890987654321");
		});
	}
	// test address null
	@Test
	void testContactClassAddressnull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345", "Jane", "Doe", "0987654321", 
					null);
		});
	}
	// test first name setter
	@Test
	void testContactClassSetFirstName() {
		Contact newContact = new Contact("999", "John", "Smith", "0123456789", "no. 4 Privet Drive");
		newContact.setFirstName("Johnny");
		assertTrue(newContact.getFirstName().equals("Johnny"));
	}
	// test first name setter length
	@Test
	void testContactClassSetFirstNameTooLong() {
		Contact newContact = new Contact("999", "John", "Smith", "0123456789", "no. 4 Privet Drive");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.setFirstName("JohnnyBeGood");
		});
	}
	// test first name setter null
	@Test
	void testContactClassSetFirstNameNull() {
		Contact newContact = new Contact("999", "John", "Smith", "0123456789", "no. 4 Privet Drive");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.setFirstName(null);
		});
	}
	//test last name setter
	@Test
	void testContactClassSetLastName() {
		Contact newContact = new Contact("999", "John", "Smith", "0123456789", "no. 4 Privet Drive");
		newContact.setLastName("Smithy");
		assertTrue(newContact.getLastName().equals("Smithy"));
	}
	// test last name setter length
	@Test
	void testContactClassSetLastNameTooLong() {
		Contact newContact = new Contact("999", "John", "Smith", "0123456789", "no. 4 Privet Drive");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.setLastName("MisterAnderson");
		});
	}
	// test last name null
	@Test
	void testContactClassSetLastNameNull() {
		Contact newContact = new Contact("999", "John", "Smith", "0123456789", "no. 4 Privet Drive");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.setLastName(null);
		});
	}
	//test phone setter
	@Test
	void testContactClassSetPhone() {
		Contact newContact = new Contact("999", "John", "Smith", "0123456789", "no. 4 Privet Drive");
		newContact.setPhone("1123456789");
		assertTrue(newContact.getPhone().equals("1123456789"));
	}
	// test phone setter too long
	@Test
	void testContactClassSetPhoneTooLong() {
		Contact newContact = new Contact("999", "John", "Smith", "0123456789", "no. 4 Privet Drive");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.setPhone("0123456789876543210");
		});
	}
	// test phone setter null
	@Test
	void testContactClassSetPhoneNull() {
		Contact newContact = new Contact("999", "John", "Smith", "0123456789", "no. 4 Privet Drive");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.setPhone(null);
		});
	}
	// test phone setter too short
	@Test
	void testContactClassSetPhoneTooShort() {
		Contact newContact = new Contact("999", "John", "Smith", "0123456789", "no. 4 Privet Drive");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.setPhone("12345");
		});
	}
	// test address setter
	@Test
	void testContactClassSetAddress() {
		Contact newContact = new Contact("999", "John", "Smith", "0123456789", "no. 4 Privet Drive");
		newContact.setAddress("12 grimmauld place");
		assertTrue(newContact.getAddress().equals("12 grimmauld place"));
	}
	// test address setter length
	@Test
	void testContactClassSetAddressTooLong() {
		Contact newContact = new Contact("999", "John", "Smith", "0123456789", "no. 4 Privet Drive");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.setAddress("Weasleys Wizard Wheezes Diagon Alley");
		});
	}
	//test address setter null
	@Test
	void testContactClassSetAddressNull() {
		Contact newContact = new Contact("999", "John", "Smith", "0123456789", "no. 4 Privet Drive");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.setAddress(null);
		});
	}
	

}